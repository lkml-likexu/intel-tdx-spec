# How to Build the SEAM-Loader

-   Follow the build instructions for the [P-SEAM-Loader](./p-seam-loader/BUILD.md) first, and take the produced binaries - pseamldr.so and pseamldr.so.consts.
-   Then follow the build instrustions for the [NP-SEAM-Loader](./np-seam-loader/BUILD.md) next.
-   The resulting binary of the NP-SEAM-Loader build, is the actual SEAM-Loader binary.
