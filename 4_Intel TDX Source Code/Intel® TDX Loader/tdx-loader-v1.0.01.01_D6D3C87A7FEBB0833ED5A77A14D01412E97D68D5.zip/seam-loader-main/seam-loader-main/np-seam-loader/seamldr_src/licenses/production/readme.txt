# SEAMLDR ACM
The project contains the following components that are covered by additional licenses:

* [Licenses/ipp-crypto/LICENSE]
* [Licenses/EdkII/LICENSE]